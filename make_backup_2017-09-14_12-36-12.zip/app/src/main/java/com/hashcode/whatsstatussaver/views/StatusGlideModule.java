package com.hashcode.whatsstatussaver.views;

/**
 * Created by oluwalekefakorede on 03/09/2017.
 */
import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public final class StatusGlideModule extends AppGlideModule {}
