# WhatsAppStatusSaver
An android app that helps you save your contacts' whatsapp statues directly to your phone with just one click
